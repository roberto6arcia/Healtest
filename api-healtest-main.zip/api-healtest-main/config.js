
module.exports = {
    SECRET: 'healtest api'
};